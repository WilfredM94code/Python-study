def submodule_1():
    print ('submodule1 from subpackage1 from package1')