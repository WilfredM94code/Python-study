def module_1():
    print ('Module1.module_1')

def module_2():
    print ('Module1.module_2')